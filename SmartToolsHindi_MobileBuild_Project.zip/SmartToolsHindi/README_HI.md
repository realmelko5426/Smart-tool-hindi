# Smart Tools Hindi — शुरुआती Android प्रोजेक्ट

इस प्रोजेक्ट में शामिल है:
- साधारण कैलकुलेटर
- प्रतिशत कैलकुलेटर
- किलोमीटर/मीटर और किलोग्राम/ग्राम कन्वर्टर
- Google AdMob का **टेस्ट** बैनर विज्ञापन

## Android Studio में खोलना
1. कंप्यूटर पर Android Studio इंस्टॉल करें: https://developer.android.com/studio
2. Android Studio में **Open** चुनें और इस फ़ोल्डर को खोलें।
3. Gradle sync पूरा होने दें।
4. फोन में Developer options और USB debugging चालू करके फोन जोड़ें, या Emulator चलाएँ।
5. Run ▶ दबाएँ।

## ज़रूरी बदलाव
- `applicationId` और `namespace` अभी `com.example.smarttoolshindi` हैं। प्रकाशित करने से पहले अपना स्थायी, यूनिक package name चुनें।
- Manifest में दिया App ID और कोड में Banner ID Google के demo/test IDs हैं। रिलीज़ से पहले अपने AdMob खाते के असली IDs डालें।
- विकास के समय कभी भी असली विज्ञापनों पर क्लिक न करें। केवल टेस्ट विज्ञापन इस्तेमाल करें।
- रिलीज़ से पहले ऐप की गोपनीयता नीति, Data safety, विज्ञापन घोषणा, सामग्री रेटिंग और अन्य Play Console घोषणाएँ सही भरें।
- यह starter project है; इस फ़ाइल पैकेज को Play Store पर अपलोड करने से पहले Android Studio में sync, build और वास्तविक डिवाइस पर परीक्षण ज़रूरी है।

## वर्तमान सीमाएँ
- यूनिट कन्वर्टर में अभी केवल km→m और kg→g है।
- ऐप को रिलीज़-रेडी मानने से पहले लेआउट, accessibility, offline व्यवहार, errors और ads placement की जाँच करें।
