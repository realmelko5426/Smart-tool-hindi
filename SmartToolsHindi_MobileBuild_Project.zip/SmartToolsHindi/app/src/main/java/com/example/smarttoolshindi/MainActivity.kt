package com.example.smarttoolshindi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent { MaterialTheme { SmartToolsApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartToolsApp() {
    var selected by remember { mutableStateOf("कैलकुलेटर") }
    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("Smart Tools Hindi", fontWeight = FontWeight.Bold)
                    Text("रोज़मर्रा के आसान टूल्स", style = MaterialTheme.typography.labelMedium)
                }
            })
        },
        bottomBar = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("विज्ञापन", style = MaterialTheme.typography.labelSmall)
                DemoBannerAd()
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("अपना टूल चुनें", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("कैलकुलेटर", "प्रतिशत", "कन्वर्टर").forEach { tool ->
                    FilterChip(
                        selected = selected == tool,
                        onClick = { selected = tool },
                        label = { Text(tool) }
                    )
                }
            }
            when (selected) {
                "कैलकुलेटर" -> BasicCalculator()
                "प्रतिशत" -> PercentageCalculator()
                else -> UnitConverter()
            }
            Text(
                "यह शुरुआती संस्करण है। प्रकाशित करने से पहले अपने ऐप का नाम, पैकेज ID, गोपनीयता नीति और AdMob सेटअप जाँचें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun BasicCalculator() {
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var operation by remember { mutableStateOf("+") }
    var result by remember { mutableStateOf<String?>(null) }

    ToolCard(title = "साधारण कैलकुलेटर") {
        NumberField("पहली संख्या", first) { first = it; result = null }
        NumberField("दूसरी संख्या", second) { second = it; result = null }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("+", "−", "×", "÷").forEach {
                FilterChip(selected = operation == it, onClick = { operation = it }, label = { Text(it) })
            }
        }
        Button(onClick = {
            val a = first.toDoubleOrNull()
            val b = second.toDoubleOrNull()
            result = when {
                a == null || b == null -> "कृपया दोनों संख्याएँ भरें"
                operation == "÷" && b == 0.0 -> "शून्य से भाग नहीं कर सकते"
                else -> {
                    val answer = when (operation) {
                        "+" -> a + b
                        "−" -> a - b
                        "×" -> a * b
                        else -> a / b
                    }
                    answer.pretty()
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("गणना करें") }
        result?.let { Text("परिणाम: $it", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun PercentageCalculator() {
    var value by remember { mutableStateOf("") }
    var percent by remember { mutableStateOf("") }
    val answer = remember(value, percent) {
        val v = value.toDoubleOrNull()
        val p = percent.toDoubleOrNull()
        if (v != null && p != null) (v * p / 100.0).pretty() else null
    }
    ToolCard(title = "प्रतिशत कैलकुलेटर") {
        NumberField("कुल संख्या (जैसे 500)", value) { value = it }
        NumberField("प्रतिशत (जैसे 20)", percent) { percent = it }
        Text(
            answer?.let { "$percent% = $it" } ?: "दोनों मान भरें",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun UnitConverter() {
    var km by remember { mutableStateOf("") }
    val meters = km.toDoubleOrNull()?.let { (it * 1000).pretty() }
    var kg by remember { mutableStateOf("") }
    val grams = kg.toDoubleOrNull()?.let { (it * 1000).pretty() }
    ToolCard(title = "यूनिट कन्वर्टर") {
        NumberField("किलोमीटर", km) { km = it }
        Text("मीटर: ${meters ?: "—"}")
        HorizontalDivider()
        NumberField("किलोग्राम", kg) { kg = it }
        Text("ग्राम: ${grams ?: "—"}")
    }
}

@Composable
fun ToolCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                content()
            }
        )
    }
}

@Composable
fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { newValue -> onValueChange(newValue.filter { it.isDigit() || it == '.' || it == '-' }) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun DemoBannerAd() {
    AndroidView(
        modifier = Modifier.fillMaxWidth().wrapContentHeight(),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                // Google's official test banner ID. Replace with your own ad unit for release.
                adUnitId = "ca-app-pub-3940256099942544/6300978111"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

private fun Double.pretty(): String =
    if (isFinite()) String.format(Locale.US, "%.4f", this).trimEnd('0').trimEnd('.') else "अमान्य परिणाम"
